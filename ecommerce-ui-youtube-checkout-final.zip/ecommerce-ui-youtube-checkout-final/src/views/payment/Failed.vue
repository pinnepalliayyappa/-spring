<template>
  <div class="text-center">
    <h1>Failed</h1>
  </div>
</template>

<script>
export default {};
</script>
