<template>
  <div class="text-center">
    <h1>Success</h1>
  </div>
</template>

<script>
export default {};
</script>
