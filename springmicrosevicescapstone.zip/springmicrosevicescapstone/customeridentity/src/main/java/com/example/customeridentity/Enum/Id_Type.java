package com.example.customeridentity.Enum;

public enum Id_Type {
	
   AADHAR,PANCARD,PASSPORT,VOTERID,DRIVINGLICENCE
   
}
