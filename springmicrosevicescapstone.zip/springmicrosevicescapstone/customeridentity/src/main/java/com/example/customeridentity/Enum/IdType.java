package com.example.customeridentity.Enum;

public class IdType {


}
