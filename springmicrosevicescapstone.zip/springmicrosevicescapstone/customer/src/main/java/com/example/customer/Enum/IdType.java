package com.example.customer.Enum;

public class IdType {


}
