package com.example.customer.Service;

import java.util.List;

import com.example.customer.DTO.SimDetailsDTO;
import com.example.customer.Entity.SimOffers;
import com.example.customer.Exception.SimCardNotValidatedException;

//import com.simactivation.DTO.SimDetailsDTO;
//import com.simactivation.Entity.SimOffers;
//import com.simactivation.Exception.SimCardNotValidatedException;

public interface SimDetailsService {

	
	public void insertRecord(SimDetailsDTO dto) throws Exception;
	public List<SimOffers> getOffersByValidation(SimDetailsDTO dto) throws SimCardNotValidatedException;
	
}
