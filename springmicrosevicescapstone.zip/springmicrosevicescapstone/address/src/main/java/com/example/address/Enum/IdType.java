package com.example.address.Enum;

public class IdType {


}
