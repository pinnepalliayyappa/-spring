package com.example.simcard.Service;

import java.util.List;

import com.example.simcard.DTO.SimDetailsDTO;
import com.example.simcard.Entity.SimOffers;
import com.example.simcard.Exception.SimCardNotValidatedException;

//import com.simactivation.DTO.SimDetailsDTO;
//import com.simactivation.Entity.SimOffers;
//import com.simactivation.Exception.SimCardNotValidatedException;

public interface SimDetailsService {

	
	public void insertRecord(SimDetailsDTO dto) throws Exception;
	public List<SimOffers> getOffersByValidation(SimDetailsDTO dto) throws SimCardNotValidatedException;
	
}
