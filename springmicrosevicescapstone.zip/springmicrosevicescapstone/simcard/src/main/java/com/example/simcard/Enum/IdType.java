package com.example.simcard.Enum;

public class IdType {


}
