package com.example.simcard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimcardApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimcardApplication.class, args);
	}

}
