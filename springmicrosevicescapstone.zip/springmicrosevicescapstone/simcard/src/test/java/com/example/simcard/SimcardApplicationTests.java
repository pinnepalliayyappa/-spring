package com.example.simcard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimcardApplicationTests {

	@Test
	void contextLoads() {
	}

}
